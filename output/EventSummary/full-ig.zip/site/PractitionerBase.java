package http://ns.electronichealth.net.au/ci/fhir/4.0/ImplementationGuide/implementationguide-eventsummary-1;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class PractitionerBase {

}
